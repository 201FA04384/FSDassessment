console.log('Hello TypeScript');
